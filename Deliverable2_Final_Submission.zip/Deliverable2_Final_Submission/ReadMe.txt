Submission Details:

1. "Implementations" folder has the source code and implementation related document. Each memeber's implementation has a corresponding ".zip" file with his name and id as the zip file name.
2. "Deliverable2_Latex.rar" file has the latex code(Deliverable2.tex) and all the latex related files.
3. File "Deliverable2.pdf" has solution to the project problems for Deliverable 2.
4. "User Stories Implementation Assignment.txt" File containts details on who Implemented which user story.